VER 1.0 BETA 
modified version of teto UTAU voicebank
Made for Kyoori-chan
all credits should be given to www.kasaneteto.jp/utau 
made with love & hope 
Elena / kyoori 

Contact: 
Email: completlyrandomaname@gmail.com (i will answer in like 3 days at best) 
Discord: Yetanotherelena 
X & Bluesky: Justaccsolol 

Free of use, no need to ask for permission 
the product is as it is, no guarantee AT all! 